import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linkaccount',
  templateUrl: './linkaccount.component.html',
  styleUrls: ['./linkaccount.component.css']
})
export class LinkaccountComponent implements OnInit {

  userName:String;
  amount:number;
  status:String;
  emailid:String;

  constructor() { }

  ngOnInit(): void {
  }

}
