import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transferfunds',
  templateUrl: './transferfunds.component.html',
  styleUrls: ['./transferfunds.component.css']
})
export class TransferfundsComponent implements OnInit {
  receiverId:number;
  amount:number;
  description:String;

  constructor() { }

  ngOnInit(): void {
  }

}
