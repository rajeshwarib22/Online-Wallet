import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-walletaccount',
  templateUrl: './walletaccount.component.html',
  styleUrls: ['./walletaccount.component.css']
})
export class WalletaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
