import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addmoney',
  templateUrl: './addmoney.component.html',
  styleUrls: ['./addmoney.component.css']
})
export class AddmoneyComponent implements OnInit {

  userName:String;
  status:String;
  amount:Number;

  constructor() { }

  ngOnInit(): void {
  }

  addEmployee(addmoneyForm:NgForm){
    if(addmoneyForm.valid){
      alert("money added succesfully")
    }
  }
}
