import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddmoneyComponent } from './addmoney/addmoney.component';
import { ContactusComponent } from './contactus/contactus.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';

import { ShowbalanceComponent } from './linkwallet/showbalance.component';
import { TransferfundsComponent } from './transferfunds/transferfunds.component';
import { ViewtransactionComponent } from './viewtransaction/viewtransaction.component';
import { WalletaccountComponent } from './walletaccount/walletaccount.component';
import { WallethomeComponent } from './wallethome/wallethome.component';
import { LinkaccountComponent } from './linkaccount/linkaccount.component';


const routes: Routes = [
  {path:"", redirectTo:'home',pathMatch:'full'},
  {path:"home", component: WallethomeComponent,
  children:[
   {path:"home/login", component:LoginComponent},
   {path:"home/contactus", component: ContactusComponent}
  ]
  },
  {path:"walletaccount", component: WalletaccountComponent,
  children:[
    {path:"walletaccount/addmoney", component:AddmoneyComponent},
    {path:"walletaccount/profile", component:ProfileComponent},
    {path:"walletaccount/balance", component:ShowbalanceComponent},
    {path:"walletaccount/link", component:LinkaccountComponent},
    {path:"walletaccount/transfer", component:TransferfundsComponent},
    {path:"walletaccount/transaction", component:ViewtransactionComponent},
   ]  
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[
    WallethomeComponent,
    LoginComponent,
    WalletaccountComponent,
    AddmoneyComponent,
    ShowbalanceComponent,
    TransferfundsComponent,
    ViewtransactionComponent,
    ProfileComponent,
    ContactusComponent,
    LinkaccountComponent
];
