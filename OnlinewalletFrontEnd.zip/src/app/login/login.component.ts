import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {MatTabsModule} from '@angular/material/tabs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) { }

  userName:String;
  password:String;
  isLogginIn:boolean;

  ngOnInit(): void {
  }

  login(form:NgForm) { 
    this.isLogginIn = true
    console.log("inside com.ts"+this.userName+this.password)
    if((!this.userName) && (!this.password))
    {
      alert('Please Enter UserName & Password')
      return
    }
    if(!this.userName)
    {
      alert('Please Enter UserName')
      return
    }
     
    if(!this.password)
    {
      alert('Please Enter Password')
      return
    }
    
    
    if (form.valid) {
      if((this.userName.match("rajeshwari")) && (this.password.match("bhirud")))
      {
        this.router.navigate(['walletaccount'])
      }
      else{
        alert('Please Enter Valid UserName & Password')
      }
    }
  }
}
